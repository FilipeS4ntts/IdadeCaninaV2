//
//  ContentView.swift
//  IdadeCanina
//
//  Created by COTEMIG on 11/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var idadehumana: String = ""
    @State private var dogAge: String = ""

    
    
    var body: some View {
        
        VStack{
            Image("cachorro1")
                .resizable()
                .scaledToFit()
                .frame(height: 150)
            
            Text("Calculadora de idade canina")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            TextField("Digite a idade humana", text: $idadehumana)
                .keyboardType(.numberPad)
                .padding()
                .background(Color.white)
                .cornerRadius(18)
                .frame(width: 250)
            
            Button(action: calcularIdadeHumana){
                Text("Calcular")
                    .padding()
                    .frame(width: 150)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            if !dogAge.isEmpty{
                Text("Idade em anos caninos: \(dogAge)")
                    .font(.headline)
                    .padding()
            }
            Button(action: TxtClear){
                dogAge = "";
            }
        }
    }
    
    func calcularIdadeHumana(){
        if let idade = Int(idadehumana) {
            let result = idade * 7
            dogAge = "\(result) anos"
        } else {
            dogAge = "Digite um numero valido"
        }
    }
    func TxtClear(){
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
