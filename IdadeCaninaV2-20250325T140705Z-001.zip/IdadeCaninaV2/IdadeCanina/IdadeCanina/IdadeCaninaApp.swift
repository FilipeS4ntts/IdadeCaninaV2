

import SwiftUI

@main
struct IdadeCaninaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
