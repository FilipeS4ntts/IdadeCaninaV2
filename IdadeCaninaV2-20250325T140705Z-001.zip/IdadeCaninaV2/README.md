<h1 align="center">Idade Canina</h1>



<h2 id=objective>:scroll: Objetivos</h2>

Treino para o uso da linguagem de Swift

<h2 id=objective>📚Sobre o Projeto</h2>

Uma calculadora que transforma a idade de um humano para a idade de um cachorro

<h2 id=technology>:toolbox: Tecnologias</h2>

Ferramentas utilizadas no desenvolvimento do projeto:

- IDE: <a href="https://dartpad.dev">XCode</a>

<h2 id=author>⭐️ Autor</h2>

Desenvolvido por: <a href="www.linkedin.com/in/filipesantanawrk" target="_blank">FilipeS4ntts</a>


